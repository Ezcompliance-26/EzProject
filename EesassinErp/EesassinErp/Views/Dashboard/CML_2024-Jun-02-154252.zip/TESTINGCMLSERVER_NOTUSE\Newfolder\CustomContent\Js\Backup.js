﻿
function GetDetailbyServer(ServerId)
{
    InstanceId = $('#ddlInstance').val();
    ServerId = $('#ddlServer').val();
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: {
            Id: InstanceId,
            ServerId: ServerId,
            Action:8
        },
        dataType: 'json',
        success: function (response) {
            $("#txtFolderLocation").val(response[0].FolderLocation);
            $("#txtDatabaseName").val(response[0].DatabaseName);
            $("#Id").val(response[0].Id);
        }
    });

}

function getServer(Id) {
    $("#ddlServer").empty();
    $("#ddlServer").append($("<option></option>").val("").html("Select"));
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: { Id: Id, Action: 2 },
        dataType: 'json',
        success: function (response) {
            $.each(response, function (key, value) {
                $("#ddlServer").append($("<option></option>").val(value.Id).html(value.ServerName));
            });
        }
    });
}
function LoadInstanceName() {
    $("#ddlInstance").empty();
    $("#ddlInstance").append($("<option></option>").val("").html("Select"));
    var Id = 0;
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: { Id: Id, Action: 1 },
        dataType: 'json',
        success: function (response) {
            $.each(response, function (key, value) {

                $("#ddlInstance").append($("<option></option>").val(value.Id).html(value.InstanceName));
            });
        }
    });
}


function ClearCBI() {
    $("#ddlInstance").val('');
    $("#ddlServer").val('');
    $("#txtFolderLocation").val('');
    $("#txtDatabaseName").val('');
    $("#ddlServer").empty();
    $("#ddlServer").append($("<option></option>").val("").html("Select"));
    $("#ddlInstance").empty();
    $("#ddlInstance").append($("<option></option>").val("").html("Select"));
    LoadInstanceName();
    BindInstanceDetail();
}

function BindInstanceDetail() {

    var Id = 5;
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: { Action: Id },
        dataType: 'json',
        success: onsuccess,
        failure: function (response) {
            alert(response.d);
        },
        error: function (response) {
            alert(response.d);
        }
    });
}
function onsuccess(response) {
    $("#tblBackupMaster").DataTable({
        destroy: true,
        data: response,
        columns: [
           {
               data: "SNO",
               name: "SNO",
           },
            {
                data: "InstanceName",
                name: "Instance Name",
            }
            ,
             {
                 data: "ServerName",
                 name: "Server Name",
             },
              {
                  data: "FolderLocation",
                  name: "Folder Location",
              },
               {
                   data: "DatabaseName",
                   name: "Database Name",
               },
                   {
                       data: null,
                       mRender: function (data, type, row) {
                           var html = '';
                           html = '<a><i onclick="CBIEditRecord(\'' + row.Id + '\')" class="fas fa-edit btnedit taskIcon"></i></a><i>/</i><i onclick="CBIDeleteRecord(\'' + row.Id + '\')" class="fas fa-trash btndelete taskIcon"></i></a>'
                           return html;
                       }
                   }

        ],
        "columnDefs": [

           {
               "targets": [0],
               "width": "30%"
           },
           {
               "targets": [1],
               "width": "20%"
           },
           {
               "targets": [2],
               "width": "20%"
           },
           {
               "targets": [3],
               "width": "20%"
           },
            {
                "targets": [4],
                "width": "20%"
            },
             {
                 "targets": [5],
                 "width": "20%"
             },


        ]
          ,
        "lengthMenu": [[10, 50, 100, 500, 1000, -1], [10, 50, 100, 500, 1000, "All"]]

    });

}

function CBIDeleteRecord(id) {
    $.ajax({
        url: '../CreateBackup/IUDInstanceDetail',
        type: 'POST',
        async: false,
        dataType: 'json',
        data: {
            Id: id,
            Action: 7,
        },
        success: function (response) {
            if (response.IsSuccess) {
                BindInstanceDetail();
                finishExecutionWithSuccess("customMessage", response.Message);
            }
            else {
                finishExecutionWithError("customMessage", response.Message);
            }
        }
    });


}

function CBIEditRecord(RowId) {
    debugger;
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: { Id: RowId, Action: 6 },
        dataType: 'json',
        success: function (response) {
            Clear();
            debugger;
            $('#btnSave').val('Update');
            $("#Id").val(response[0].Id);
            LoadInstanceName();
            getServer(response[0].InstanceId);
            setTimeout($("#ddlInstance").val(response[0].InstanceId), 300);
            $("#ddlServer").val(response[0].ServerId);
            $("#txtFolderLocation").val(response[0].FolderLocation);
            $("#txtDatabaseName").val(response[0].DatabaseName);
            $("#txtBackupLocation").val(response[0].BackupLocation);

        }
    });
}


function Automatic() {
    $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Please wait')
    $('#btnzip').prop('disabled', true); 
    var Id = $("#Id").val();
    var Suffix = $("#txtSuffix").val();
    setTimeout(function ()
    {
        $.ajax({
            url: '../CreateBackup/ZipFolder',
            type: 'POST',
            async: false,
            dataType: 'json',
            data: {
                Id: Id,
                Action: 9,
                Suffix: Suffix,
            },
            success: function (response) { 
                if (response.IsSuccess) {
                    $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Uploaded Successfully')
                    $('#btnzip').prop('disabled', true); 
                    setTimeout(function () {
                        $('#btnzip').html('Create Manual upload Backup');
                        $('#btnzip').prop('disabled', false);
                        ClearCBI();
                    }, 3000); 
                }
                else {

                    setTimeout(function () {
                        $('#btnzip').html('Create Manual upload Backup');
                        $('#btnzip').prop('disabled', false);
                    }, 3000);
                    finishExecutionWithError("customMessage", response.Message);
                }
               
            }
        });
    }, 300);
}
function ManualBackup()
{ 
    if ($("#ddlInstance").val() == '')
    {
        $("#ddlInstance").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#ddlInstance").focus();
        return false;
    }
    else if ($("#ddlServer").val() == '') {
        $("#ddlServer").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#ddlInstance").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#ddlServer").focus();
        return false;
    }
    else if ($("#txtFolderLocation").val() == '') {
        $("#txtFolderLocation").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#ddlServer").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtFolderLocation").focus();
        return false;
    }
    else if ($("#txtDatabaseName").val() == '') {
        $("#txtDatabaseName").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtFolderLocation").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtDatabaseName").focus();
        return false;
    } 
    else
    {
        $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Please wait')
        $('#btnzip').prop('disabled', true);
        $("#txtDatabaseName").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        var InstanceId = $("#ddlInstance").val();
        var ServerId = $("#ddlServer").val(); 
        Automatic(); 
    }
}