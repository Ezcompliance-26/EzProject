﻿  
  
function loaddetail()
{ 
      $("#tblServer").DataTable({
        "responsive": true,
        "autoWidth": true,
        "serverSide": false,
        "DeferLoading": 0,
        dom: 'Bfrtip',
        retrieve: true,
        "ajax": {
            url: '../CreateBackup/GetDataTable',
        },
        type: 'POST',
        datatype: 'json',
        columns: [
           {
               data: "SNO",
               name: "SNO",
           },
            {
                data: "ServerName",
                name: "ServerName",
            }
            ,
             {
                 data: "ServerUserName",
                 name: "Server UserName",
             },
              {
                  data: "ServerPassword",
                  name: "Server Password",
              },
               {
                   data: "WebURL",
                   name: "Web URL",
               }
               ,
                {
                    data: "DatabaseSource",
                    name: "Database Source",
                },
                {
                    data: "DatabaseName",
                    name: "Database Name",
                },
                 {
                     data: "DatabaseUserName",
                     name: "Database UserName",
                 },
                 
                 {
                     data: "DatabasePassword",
                     name: "Database Password",
                 },
                  {
                      data: "CodePath",
                      name: "Code Path",
                  }, 
                  {
                      data: "IsActive",
                      name: "Status",
                  } 
                   ,
                   {
                       data: "UpdatedOn",
                       name: "Last UpdateOn",
                   },
                  {
                      data: "BackupStatus",
                      name: "Backup Status",
                  }, 
                                  
                   {
                       data: null,
                       mRender: function (data, type, row) {
                           var html = '';
                           html = '<a><i onclick="EditRecord(\'' + row.Id + '\')" class="fas fa-edit btnedit taskIcon"></i></a><i>/</i><i onclick="DeleteRecord(\'' + row.Id + '\')" class="fas fa-trash btndelete taskIcon"></i></a>'
                           return html;
                       }
                   }
            , { data: "Id", name: "Id" }
        ],
        "columnDefs": [

           {
               "targets": [0],
               "width": "30%"
           },
           {
               "targets": [1],
               "width": "20%"
           },
           {
               "targets": [2],
               "width": "20%"
           },
           {
               "targets": [3],
               "width": "20%"
           },
            {
                "targets": [4],
                "width": "20%"
            },
             {
                 "targets": [5],
                 "width": "20%"
             },
              {
                  "targets": [6],
                  "width": "20%"
              },
               {
                   "targets": [7],
                   "width": "20%"
               },
                {
                    "targets": [8],
                    "width": "20%"
                },
                {
                    "targets": [9],
                    "width": "20%"
                },
                {
                    "targets": [10],
                    "width": "20%"
                }, 
                {
                    "targets": [11],
                    "width": "20%"
                }, 
                {
                    "targets": [12],
                    "width": "20%"
                },
                {
                    "targets": [13],
                    "width": "20%"
                },
           
                {
                    "targets": [14],
                    "visible": false,
                    "searchable": false
                },

         
        ]
        ,
        "lengthMenu": [[10, 50, 100, 500, 1000, -1], [10, 50, 100, 500, 1000, "All"]]

    });
}

function getServer(Id) {
    $("#ddlServer").empty();
    $("#ddlServer").append($("<option></option>").val("").html("Select"));
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: { Id: Id, Action: 2 },
        dataType: 'json',
        success: function (response) {
            $.each(response, function (key, value) { 
                $("#ddlServer").append($("<option></option>").val(value.Id).html(value.ServerName));
            });
        }
    });
}
function LoadInstanceName()
{
    $("#ddlInstance").empty();
    $("#ddlInstance").append($("<option></option>").val("").html("Select"));
    var Id = 0;
  $.ajax({
    url: '../CreateBackup/GetInstanceDetail',
    type: 'POST',
    async: false,
    data: { Id: Id ,Action:1},
    dataType: 'json',
    success: function (response) {
        $.each(response, function (key, value) {

            $("#ddlInstance").append($("<option></option>").val(value.Id).html(value.InstanceName));
            });
    }
});
}


function ClearCBI()
{
    $("#ddlInstance").val('');
    $("#ddlServer").val('');
    $("#txtFolderLocation").val('');
    $("#txtDatabaseName").val('');
    $("#ddlServer").empty();
    $("#ddlServer").append($("<option></option>").val("").html("Select"));
    $("#ddlInstance").empty();
    $("#ddlInstance").append($("<option></option>").val("").html("Select"));
    LoadInstanceName();
    BindInstanceDetail();
}

function BindInstanceDetail() {

    var Id = 5;
    $.ajax({
        url: '../CreateBackup/GetInstanceDetail',
        type: 'POST',
        async: false,
        data: { Action: Id },
        dataType: 'json',
        success: onsuccess,
        failure: function (response) {
            alert(response.d);
        },
        error: function (response) {
            alert(response.d);
        }
    });
}
    function onsuccess(response) {
        $("#tblBackupMaster").DataTable({
            destroy: true ,
                 data: response,
                columns: [
                   {
                       data: "SNO",
                       name: "SNO",
                   },
                    {
                        data: "InstanceName",
                        name: "Instance Name",
                    }
                    ,
                     {
                         data: "ServerName",
                         name: "Server Name",
                     },
                      {
                          data: "FolderLocation",
                          name: "Folder Location",
                      },
                       {
                           data: "DatabaseName",
                           name: "Database Name",
                       }, 
                           {
                               data: null,
                               mRender: function (data, type, row) {
                                   var html = '';
                                   html = '<a><i onclick="CBIEditRecord(\'' + row.Id + '\')" class="fas fa-edit btnedit taskIcon"></i></a><i>/</i><i onclick="CBIDeleteRecord(\'' + row.Id + '\')" class="fas fa-trash btndelete taskIcon"></i></a>'
                                   return html;
                               }
                           }
                    
                ],
                "columnDefs": [

                   {
                       "targets": [0],
                       "width": "30%"
                   },
                   {
                       "targets": [1],
                       "width": "20%"
                   },
                   {
                       "targets": [2],
                       "width": "20%"
                   },
                   {
                       "targets": [3],
                       "width": "20%"
                   },
                    {
                        "targets": [4],
                        "width": "20%"
                    },
                     {
                         "targets": [5],
                         "width": "20%"
                     } ,


                ]
              ,
                "lengthMenu": [[10, 50, 100, 500, 1000, -1], [10, 50, 100, 500, 1000, "All"]]

            }); 
  
}

    function CBIDeleteRecord(id) {
        $.ajax({
            url: '../CreateBackup/IUDInstanceDetail',
            type: 'POST',
            async: false,
            dataType: 'json',
            data: {
                Id: id,
                Action:7,
            },
            success: function (response) {
                if (response.IsSuccess) {
                    BindInstanceDetail();
                    finishExecutionWithSuccess("customMessage", response.Message); 
                }
                else {
                    finishExecutionWithError("customMessage", response.Message);
                }
            }
        });


    }

    function CBIEditRecord(RowId) {
        debugger; 
        $.ajax({
            url: '../CreateBackup/GetInstanceDetail',
            type: 'POST',
            async: false,
            data: { Id: RowId,Action:6 },
            dataType: 'json',
            success: function (response) { 
                    Clear();
                    debugger;
                    $('#btnSave').val('Update'); 
                    $("#Id").val(response[0].Id);
                    LoadInstanceName();
                    getServer(response[0].InstanceId);
                    setTimeout($("#ddlInstance").val(response[0].InstanceId), 300);
                    $("#ddlServer").val(response[0].ServerId);
                    $("#txtFolderLocation").val(response[0].FolderLocation);
                    $("#txtDatabaseName").val(response[0].DatabaseName);
                    $("#txtBackupLocation").val(response[0].BackupLocation);
                
            }
        });
    }



function SaveBMRecord()
{
    if ($("#ddlInstance").val() == '') {
        $("#ddlInstance").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#ddlInstance").focus();
        return false;
    }
    else if ($("#ddlServer").val() == '') {
        $("#ddlServer").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#ddlInstance").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#ddlServer").focus();
        return false;
    }
    else if ($("#txtFolderLocation").val() == '') {
        $("#txtFolderLocation").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#ddlServer").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtFolderLocation").focus();
        return false;
    }
    else if ($("#txtDatabaseName").val() == '') {
        $("#txtDatabaseName").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtFolderLocation").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtDatabaseName").focus();
        return false;
    }
    else if ($("#txtBackupLocation").val() == '') {
        $("#txtBackupLocation").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtDatabaseName").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtBackupLocation").focus();
        return false;
    } 
    else {
        $("#txtBackupLocation").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        var InstanceId = $("#ddlInstance").val();
        var ServerId = $("#ddlServer").val();
        var FolderLocation = $("#txtFolderLocation").val();
        var DatabaseName = $("#txtDatabaseName").val();
        var BackupLocation = $("#txtBackupLocation").val(); 
        if ($('#btnSave').val() == 'Update') {
            var Id = $("#Id").val();
            var actionfor = 4;
        }
        else {
            var Id = 0;
            var actionfor = 3;
        }
        debugger;
        $.ajax({
            url: '../CreateBackup/IUDInstanceDetail', 
            type: 'POST',
            dataType: 'json',
            data: {
                Id:Id,
                InstanceId: InstanceId,
                ServerId: ServerId,
                FolderLocation: FolderLocation,
                DatabaseName: DatabaseName,
                BackupLocation: BackupLocation, 
                Action: actionfor
            },
            success: function (response) { 
                if (response.IsSuccess)
                {
                    ClearCBI();
                    finishExecutionWithSuccess("customMessage", response.Message);
                    BindInstanceDetail(); 
                } 
            } 
        });

    }
}

function makeTimer() {

    var interval = "";

    var today = new Date();
    var tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    endTime = (Date.parse(tomorrow) / 1000);

    var myDate = new Date();
    myDate.setDate(myDate.getDate() + 1);
    // format a date
    var NextDay = myDate.getDate() + '/' + ("0" + (myDate.getMonth() + 1)).slice(-2) + '/' + myDate.getFullYear();


    setInterval(function () {
        var now = new Date();
        now = (Date.parse(now) / 1000);

        var timeLeft = endTime - now;

        var days = Math.floor(timeLeft / 86400);
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

        if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }
        $("#showcounter").html("Next Backup Sechdule on : " + NextDay + " CountDown : " + hours + ":" + minutes + ":" + seconds);
        if (hours = "00" && minutes == "00" && seconds == "01") {
            Automatic();
        }

    }, 1000);

} 
 
function Automatic() {
    $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Please wait')
    $('#btnzip').prop('disabled', true); 
    setTimeout(function () {
        $.ajax({
            url: '../CreateBackup/ZipFolder',
            type: 'POST',
            async: false,
            dataType: 'json',
            data: {
                Id: 1,
            },
            success: function (response) {
               
                if (response.IsSuccess) { 
                    $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Uploaded Successfully')
                    $('#btnzip').prop('disabled', true);
                    loaddetail();
                    setTimeout(function () {
                        $('#btnzip').html('Create Manual upload Backup');
                        $('#btnzip').prop('disabled', false);
                        makeTimer();
                    }, 3000);

                }
                else {

                    setTimeout(function () {
                        $('#btnzip').html('Create Manual upload Backup');
                        $('#btnzip').prop('disabled', false);
                    }, 3000);
                    finishExecutionWithError("customMessage", response.Message);
                }
                $("#tblServer").DataTable().ajax.reload();
            }
        });
    }, 200);  
}
function AutomaticCreateZip(Ids) {
    var Id = Ids;
    $.ajax({
        url: '../CreateBackup/GetBackupDetail',
        type: 'POST',
        async: false,
        data: { Id: Id },
        dataType: 'json',
        success: function (response) {
            if (response.IsSuccess) {
                debugger;
                Id = response.Data.Id;
                ServerName = response.Data.ServerName;
                ServerUserName = response.Data.ServerUserName;
                ServerPassword = response.Data.ServerPassword;
                WebURL = response.Data.WebURL;
                DatabaseSource = response.Data.DatabaseSource;
                DatabaseName = response.Data.DatabaseName;
                DatabaseUserName = response.Data.DatabaseUserName;
                DatabasePassword = response.Data.DatabasePassword;
                CodePath = response.Data.CodePath;
                AfterclickCreateZip(Id,ServerName, ServerUserName, ServerPassword, WebURL, DatabaseSource, DatabaseName, DatabaseUserName, DatabasePassword, CodePath);
            }
        }
    });
}



function DeleteRecord(id) {
    $.ajax({
        url: '../CreateBackup/DeleteRecordDetail',
     //   url: '@Url.Action("DeleteRecordDetail", "CreateBackup")', //'/GetBusinessUnit/Common?id=' + id,
        type: 'POST',
        async: false,
        dataType: 'json',
        data: {
            Id: id
        },
        success: function (response) {
            if (response.IsSuccess) {
                $("#tblServer").DataTable().ajax.reload();
                finishExecutionWithSuccess("customMessage", response.Message);
                // newRole();
            }
            else {
                finishExecutionWithError("customMessage", response.Message);
            }
        }
    });


}

function EditRecord(RowId) {
    debugger;
    $.ajax({
        url: '../CreateBackup/GetBackupDetail', 
        type: 'POST',
        async: false,
        data: { Id: RowId },
        dataType: 'json',
        success: function (response) {
            if (response.IsSuccess) {
                Clear();
                debugger;
                $('#btnSave').val('Update');
                $('#btnzip').attr('style', 'display:block');
             
                $("#Id").val(response.Data.Id);
                $("#txtServerName").val(response.Data.ServerName);
                $("#txtServerUserName").val(response.Data.ServerUserName);
                $("#txtServerPassword").val(response.Data.ServerPassword);
                $("#txtWebURL").val(response.Data.WebURL);
                $("#txtDatabaseSource").val(response.Data.DatabaseSource);

                $("#txtDatabaseName").val(response.Data.DatabaseName);
                $("#txtDatabaseUserName").val(response.Data.DatabaseUserName);
                
                $("#txtDatabasePassword").val(response.Data.DatabasePassword);
                $("#txtCodePath").val(response.Data.CodePath);
                $("#ddlActive").val(response.Data.IsActive);
            }
        }
    });
}



function CreateZip() {
    var Id = $('#Id').val();
    $.ajax({
        url: '../CreateBackup/GetBackupDetail', 
        type: 'POST',
        async: false,
        data: { Id: Id },
        dataType: 'json',
        success: function (response) {
            if (response.IsSuccess) {
                debugger;
                ServerName = response.Data.ServerName;
                ServerUserName = response.Data.ServerUserName;
                ServerPassword = response.Data.ServerPassword;
                WebURL = response.Data.WebURL;
                DatabaseSource = response.Data.DatabaseSource;
                DatabaseName = response.Data.DatabaseName;
                DatabaseUserName = response.Data.DatabaseUserName; 
                DatabasePassword = response.Data.DatabasePassword;
                CodePath = response.Data.CodePath;
                AfterclickCreateZip(ServerName, ServerUserName, ServerPassword, WebURL, DatabaseSource, DatabaseName,DatabaseUserName, DatabasePassword, CodePath);
            }
        }
    });
}
function AfterclickCreateZip(Id,ServerName, ServerUserName, ServerPassword, WebURL, DatabaseSource, DatabaseName,DatabaseUserName, DatabasePassword, CodePath) {
    $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Please wait')
    $('#btnzip').prop('disabled', true);
    debugger;
    $.ajax({
        url: '../CreateBackup/ZipFolder', 
        type: 'POST',
        dataType: 'json',
        data: {
            Id: Id,
            ServerName: ServerName,
            ServerUserName: ServerUserName,
            ServerPassword: ServerPassword,
            WebURL: WebURL,
            DatabaseSource: DatabaseSource,
            DatabaseName: DatabaseName,
            DatabaseUserName : DatabaseUserName,
            DatabasePassword: DatabasePassword,
            CodePath: CodePath
        },
        success: function (response) {
            if (response.IsSuccess)
            {
                debugger;
                //loaddetail();
                //$('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Uploaded Successfully')
                //$('#btnzip').prop('disabled', true);
                //setTimeout(function () {
                //    $('#btnzip').html('Create Manual upload Backup');
                //    $('#btnzip').prop('disabled', false);
                //    makeTimer();
                //}, 3000);
            }
            else {
                
                setTimeout(function () {
                    $('#btnzip').html('Create Manual upload Backup');
                    $('#btnzip').prop('disabled', false);
                }, 3000);
                finishExecutionWithError("customMessage", response.Message);
            }
            
        },
        error: function (response) {
            $('#btnzip').html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Uploaded Successfully')
            $('#btnzip').prop('disabled', true);
            setTimeout(function () {
                $('#btnzip').html('Create Manual upload Backup');
                $('#btnzip').prop('disabled', false);
                makeTimer();
            }, 3000);
        }
    });
}


function SaveRecord() {
    if ($("#txtServerName").val() == '') {
        $("#txtServerName").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtServerName").focus();
        return false;
    }
    else if ($("#txtServerUserName").val() == '') {
        $("#txtServerUserName").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtServerName").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtServerUserName").focus();
        return false;
    }
    else if ($("#txtServerPassword").val() == '') {
        $("#txtServerPassword").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtServerUserName").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtServerPassword").focus();
        return false;
    }
    else if ($("#txtWebURL").val() == '') {
        $("#txtWebURL").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtServerPassword").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtWebURL").focus();
        return false;
    }
    else if ($("#txtDatabaseSource").val() == '') {
        $("#txtDatabaseSource").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtWebURL").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtDatabaseSource").focus();
        return false;
    } 
    else if ($("#txtDatabaseName").val() == '') {
        $("#txtDatabaseName").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtDatabaseSource").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtDatabaseName").focus();
        return false;
    }
    else if ($("#txtDatabaseUserName").val() == '') {
        $("#txtDatabaseUserName").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtDatabaseName").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtDatabaseUserName").focus();
        return false;
    }
    
    else if ($("#txtDatabasePassword").val() == '') {
        $("#txtDatabasePassword").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtDatabaseUserName").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtDatabasePassword").focus();
        return false;
    }
    else if ($("#txtCodePath").val() == '') {
        $("#txtDatabasePassword").attr('style', 'border-bottom: 1px solid #DC143C')
        $("#txtDatabasePassword").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        $("#txtCodePath").focus();
        return false;
    } 
    else {
        $("#txtCodePath").attr('style', 'border-bottom-color: #DC143C;border-block-width: 1px;')
        var ServerName = $("#txtServerName").val();
        var ServerUserName = $("#txtServerUserName").val();
        var ServerPassword = $("#txtServerPassword").val();
        var WebURL = $("#txtWebURL").val();
        var DatabaseSource = $("#txtDatabaseSource").val();
        var DatabaseName = $("#txtDatabaseName").val();
        var DatabaseUserName = $("#txtDatabaseUserName").val();
        var DatabasePassword = $("#txtDatabasePassword").val();
        var CodePath = $("#txtCodePath").val();
        var IsActive = $("#ddlActive").val();

        if ($('#btnSave').val() == 'Update') {
            var Id = $("#Id").val();
            var actionfor = 2;
        }
        else {
            var Id = 0;
            var actionfor = 1;
        }
        debugger;
        $.ajax({
            url: '../CreateBackup/IUDCreateBackup',
            //url: '@Url.Action("IUDCreateBackup", "CreateBackup")',
            type: 'POST',
            dataType: 'json',
            data: {
                IsActive : IsActive,
                ServerName: ServerName,
                ServerUserName: ServerUserName,
                ServerPassword: ServerPassword,
                WebURL: WebURL,
                DatabaseSource: DatabaseSource,
                DatabaseName: DatabaseName,
                DatabaseUserName : DatabaseUserName,
                DatabasePassword: DatabasePassword,
                CodePath: CodePath,
                Id: Id,
                Action: actionfor
            },
            success: function (response) {
                debugger;

                if (response.IsSuccess) {

                    $("#tblServer").DataTable().ajax.reload();
                    if ($('#btnSave').val() == 'Update') {
                        finishExecutionWithSuccess("customMessage", 'Record has been Updated successfully.');
                    }
                    else {
                        finishExecutionWithSuccess("customMessage", response.Message);
                    }
                    Clear();
                }
                else {
                    var myfield = $('.validate-my-field')
                    myfield.removeClass('field-validation-error');
                    myfield.next('span[data-valmsg-for]').removeClass("field-validation-error").addClass("field-validation-valid").html("");
                    $.each(response.Message, function (Key, ErrorMessage) {
                        if (ErrorMessage != null) {
                            $errorSpan = $("span[data-valmsg-for='" + ErrorMessage.Key + "']");
                            $errorSpan.html("<span>" + ErrorMessage.ErrorMessage + "</span>");
                            $errorSpan.show();

                        }
                    });
                };
            },
            error: function (response) {

            }
        });

    }


}


function Clear() {
    $("#Id").val('');
    $("#txtServerName").val('');
    $("#txtServerUserName").val('');
    $("#txtServerPassword").val('');
    $("#txtWebURL").val('');
    $("#txtDatabaseSource").val('');
    $("#txtDatabaseName").val('');
    $("#txtDatabasePassword").val('');
    $("#txtDatabaseUserName").val('');
    $("#txtCodePath").val('');
    $('#btnSave').val('Save'); 
    $('#showcounter').html('Click Manual Backup Button, Find Next Schedule');
    $("#txtDatabaseUserName").val('NA');
    $("#txtDatabasePassword").val('NA');
    
}